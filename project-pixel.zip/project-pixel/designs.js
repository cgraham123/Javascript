// Select color input
const colorInput = document.getElementById('colorPicker');

// Select size input
const inputHeight = document.getElementById('inputHeight');
const inputWidth = document.getElementById('inputWidth');

// When size is submitted by the user, call makeGrid()
document.getElementById('sizePicker').addEventListener('submit', function(e){
    // Prevent defaukt form submission
    e.preventDefault();
    makeGrid();
});

function makeGrid() {
    height =  inputHeight.value;
    width =  inputWidth.value;

    let table = document.getElementById('pixelCanvas');

    // Clear the pixelCanvas
    table.innerHTML = "";

    // loop for each tabke row
    for (let i = 0; i < height; i++){
        let tr = document.createElement('tr');

        // loop to create column
        for (let j = 0; j < width; j++){
            let td = document.createElement('td');
            
            // Add click event to the created table cell
            td.addEventListener('click', function(){
                // Change the cell background color with the current selected color
                this.style.backgroundColor = colorInput.value;

            });
            tr.appendChild(td);
        }
        table.appendChild(tr);


    }
}